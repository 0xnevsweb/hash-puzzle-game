export const puzzles = [
  {
    id: 1,
    name: "Easy",
    islands: [
      { id: 0, x: 2, y: 2, value: 2 },
      { id: 1, x: 6, y: 2, value: 2 },
      { id: 2, x: 2, y: 6, value: 2 },
      { id: 3, x: 6, y: 6, value: 2 }
    ]
  },
  {
    id: 2,
    name: "Medium",
    islands: [
      { id: 0, x: 2, y: 2, value: 3 },
      { id: 1, x: 6, y: 2, value: 2 },
      { id: 2, x: 10, y: 2, value: 3 },
      { id: 3, x: 4, y: 6, value: 2 },
      { id: 4, x: 8, y: 6, value: 2 }
    ]
  },
  {
    id: 3,
    name: "Hard",
    islands: [
      { id: 0, x: 2, y: 2, value: 4 },
      { id: 1, x: 6, y: 2, value: 2 },
      { id: 2, x: 10, y: 2, value: 4 },
      { id: 3, x: 2, y: 6, value: 2 },
      { id: 4, x: 6, y: 6, value: 4 },
      { id: 5, x: 10, y: 6, value: 2 }
    ]
  }
];
